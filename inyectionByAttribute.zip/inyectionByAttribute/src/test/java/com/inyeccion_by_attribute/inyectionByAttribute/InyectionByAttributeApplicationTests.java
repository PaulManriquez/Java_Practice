package com.inyeccion_by_attribute.inyectionByAttribute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InyectionByAttributeApplicationTests {

	@Test
	void contextLoads() {
	}

}
